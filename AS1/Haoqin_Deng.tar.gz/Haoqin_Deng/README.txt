5148166401
python3 server.py ...(arguments)
python3 client.py ...(arguments)
can only type in client terminal